"""
Linear Regression module for the Flight ML project.

Target:
    weather_delay (automatically detected if present)

This module:
- Loads flight_data.csv
- Removes rows with missing target
- Removes columns that contain no usable values
- One-hot encodes categorical columns
- Scales numeric columns
- Splits the data into train/test sets
- Trains Linear Regression
- Calculates MAE, MSE, RMSE and R2
- Creates Actual vs Predicted and Residual plots
"""

from pathlib import Path
import json

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "data" / "flight_data.csv"
OUTPUT_DIR = BASE_DIR / "static" / "linear_regression"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def detect_target(df):
    """Use weather_delay for this flight dataset; fall back to another delay column."""
    candidates = [
        "weather_delay",
        "departure_delay",
        "arrival_delay",
        "delay",
        "price",
        "fare",
    ]

    for column in candidates:
        if column in df.columns:
            return column

    numeric = df.select_dtypes(include=np.number).columns.tolist()
    if not numeric:
        raise ValueError("No numeric target column was found in the dataset.")

    return numeric[-1]


def build_preprocessor(X):
    numeric_cols = X.select_dtypes(include=np.number).columns.tolist()
    categorical_cols = X.select_dtypes(exclude=np.number).columns.tolist()

    numeric_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])

    categorical_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore")),
    ])

    transformers = []

    if numeric_cols:
        transformers.append(
            ("numeric", numeric_pipeline, numeric_cols)
        )

    if categorical_cols:
        transformers.append(
            ("categorical", categorical_pipeline, categorical_cols)
        )

    return ColumnTransformer(transformers=transformers)


def train_linear_regression():
    df = pd.read_csv(DATA_PATH)

    target = detect_target(df)

    # Convert target to numeric and remove rows where target is unavailable.
    df[target] = pd.to_numeric(df[target], errors="coerce")
    df = df.dropna(subset=[target]).copy()

    X = df.drop(columns=[target])
    y = df[target]

    # Remove columns with no usable values.
    empty_columns = [
        column for column in X.columns
        if X[column].notna().sum() == 0
    ]

    if empty_columns:
        X = X.drop(columns=empty_columns)

    # Remove columns that contain only one unique non-null value.
    constant_columns = [
        column for column in X.columns
        if X[column].nunique(dropna=True) <= 1
    ]

    if constant_columns:
        X = X.drop(columns=constant_columns)

    if X.shape[1] == 0:
        raise ValueError("No usable input features remain after preprocessing.")

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.20,
        random_state=42
    )

    preprocessor = build_preprocessor(X_train)

    X_train_processed = preprocessor.fit_transform(X_train)
    X_test_processed = preprocessor.transform(X_test)

    model = LinearRegression()
    model.fit(X_train_processed, y_train)

    predictions = model.predict(X_test_processed)

    mae = mean_absolute_error(y_test, predictions)
    mse = mean_squared_error(y_test, predictions)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, predictions)

    # Actual vs Predicted plot
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.scatter(y_test, predictions, alpha=0.5)
    minimum = min(y_test.min(), predictions.min())
    maximum = max(y_test.max(), predictions.max())
    ax.plot([minimum, maximum], [minimum, maximum])
    ax.set_title("Actual vs Predicted")
    ax.set_xlabel("Actual")
    ax.set_ylabel("Predicted")
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "actual_vs_predicted.png",
        dpi=120,
        bbox_inches="tight"
    )
    plt.close(fig)

    # Residual plot
    residuals = y_test - predictions

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.scatter(predictions, residuals, alpha=0.5)
    ax.axhline(0, linestyle="--")
    ax.set_title("Residual Plot")
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Residual")
    fig.tight_layout()
    fig.savefig(
        OUTPUT_DIR / "residual_plot.png",
        dpi=120,
        bbox_inches="tight"
    )
    plt.close(fig)

    metrics = {
        "target": target,
        "rows_used": int(len(df)),
        "features_used": int(X.shape[1]),
        "training_rows": int(len(X_train)),
        "testing_rows": int(len(X_test)),
        "mae": round(float(mae), 4),
        "mse": round(float(mse), 4),
        "rmse": round(float(rmse), 4),
        "r2": round(float(r2), 4),
    }

    return metrics


if __name__ == "__main__":
    result = train_linear_regression()
    print("\nLinear Regression Results")
    print("-" * 30)
    for key, value in result.items():
        print(f"{key}: {value}")
